<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Pinterest Test-2</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>d3893bcb-03e2-4f30-9d2c-4761a615b4d7</testSuiteGuid>
   <testCaseLink>
      <guid>de52bf2c-1c3f-4610-9ef3-f6ff174d3481</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Pinterest Test-2/Login invalid</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>c6972abe-4499-4527-b5ad-7abdff4c092b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Pinterest Test-2/Login (valid)</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>7200e654-cf64-4754-a024-2a9eae1060b8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Pinterest Test-2/Search pin</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>a6c5576e-fa3a-4fb9-9dfd-475342e6a489</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Pinterest Test-2/Menghapus pin</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    